﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation
{
    public class InfestationSpores : Suplement
    {
        const int InitialPowerEffect = -1;
        const int InitialHealthEffect = 0;
        const int InitialAggressionEffect = 20;
        public InfestationSpores()
            : base(InitialPowerEffect, InitialHealthEffect, InitialAggressionEffect)
        {
        }

        public override void ReactTo(ISupplement otherSupplement)
        {
            if (otherSupplement is InfestationSpores)
            {
                this.AggressionEffect = 0;
                this.HealthEffect = 0;
                this.PowerEffect = 0;   
            }
        }
    }
}
