﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation
{
    public class CustumHoldingPen : HoldingPen
    {
        protected override void ExecuteInsertUnitCommand(string[] commandWords)
        {
            switch (commandWords[1])
            {
                case "Tank":
                    InsertUnit(new Tank(commandWords[2]));
                    break;
                case "Marine":
                    InsertUnit(new Marine(commandWords[2]));
                    break;
                case "Queen":
                    InsertUnit(new Queen(commandWords[2]));
                    break;
                case "Parasite":
                    InsertUnit(new Parasite(commandWords[2]));
                    break;
                default:
                    base.ExecuteInsertUnitCommand(commandWords);
                    break;
            }
        }

        //Unit targetUnit = this.GetUnit(interaction.TargetUnit);

        //           targetUnit.DecreaseBaseHealth(interaction.SourceUnit.Power);
        //           break;

        protected override void ProcessSingleInteraction(Interaction interaction)
        {
            switch (interaction.InteractionType)
            {
                case InteractionType.Infest:
                    if (interaction.TargetUnit.UnitClassification == UnitClassification.Biological)
                    {
                        if (interaction.SourceUnit.UnitClassification == UnitClassification.Biological)
                        {
                            Unit current = GetUnit(interaction.TargetUnit);

                            current.AddSupplement(new InfestationSpores());
                            return;
                        }
                        else
                        {
                            return;
                        }
                    }

                    else if (interaction.TargetUnit.UnitClassification == UnitClassification.Mechanical)
                    {
                        if (interaction.SourceUnit.UnitClassification == UnitClassification.Psionic)
                        {
                            Unit current = GetUnit(interaction.TargetUnit);

                            current.AddSupplement(new InfestationSpores());
                            return;
                        }
                        else
                        {
                            return;
                        }

                    }

                    else if (interaction.TargetUnit.UnitClassification == UnitClassification.Mechanical)
                    {
                        if (interaction.SourceUnit.UnitClassification == UnitClassification.Psionic)
                        {
                            Unit current = GetUnit(interaction.TargetUnit);

                            current.AddSupplement(new InfestationSpores());
                            return;
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        Unit current = GetUnit(interaction.TargetUnit);

                        current.AddSupplement(new InfestationSpores());
                        return;
                    }

                    break;
                default:
                    base.ProcessSingleInteraction(interaction);
                    break;
            }

        }

        protected override void ExecuteAddSupplementCommand(string[] commandWords)
        {
            switch (commandWords[1])
            {
                case "PowerCatalyst":
                    {
                        Unit current = GetUnit(commandWords[2]);
                        if (current != null)
                        {
                            current.AddSupplement(new PowerCatalyst(3, 0, 0));
                        }
                    }
                    break;
                case "HealthCatalyst ":
                    {
                        Unit current = GetUnit(commandWords[2]);
                        if (current != null)
                        {
                            current.AddSupplement(new HealthCatalyst(0, 3, 0));
                        }
                    }
                    break;
                case "AggressionCatalyst":
                    {
                        Unit current = GetUnit(commandWords[2]);
                        if (current != null)
                        {
                            current.AddSupplement(new AggressionCatalyst(0, 0, 3));
                        }
                    }
                    break;
                case "Weapon":
                    {
                        Unit current = GetUnit(commandWords[2]);
                        if (current != null)
                        {
                            current.AddSupplement(new Weapon());
                        }
                    }
                    break;
                default:
                    break;
            }
        }
    }
}
