﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation
{
    public class Marine : Human
    {
        public Marine(string id)
            : base(id)
        {
            //TODO: add suplements
            this.AddSupplement(new WeaponrySkill()); 
        }

    }
}
